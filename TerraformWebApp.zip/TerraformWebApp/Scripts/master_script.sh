#! /bin/bash
cd /home/ubuntu
sudo apt-get update -y > /dev/null
echo "---> Update completato"
sudo apt-get upgrade -y > /dev/null
echo "---> Upgrade completato"

sudo apt-get update -y > /dev/null
sudo apt-get install -y python3-pip > /dev/null
sudo apt-get install -y git > /dev/null
sudo apt-get install -y node > /dev/null
sudo apt-get install -y npm > /dev/null
apt-get install -y unzip > /dev/null
echo "--->######################### gdown download #########################"
sudo pip3 --no-cache-dir install gdown > /dev/null
echo "######################### libreria tensorflow #########################"
sudo sudo --no-cache-dir pip3 install -y --upgrade pip
sudo pip3 --no-cache-dir install  tensorflow > /dev/null
echo "######################### file webAPP #########################"
gdown https://drive.google.com/file/d/1S_EbLecclv3pjlhCqaf2p6qtbXQiiGb_/view?usp=sharing
gdown https://drive.google.com/file/d/1UKNY_Ay6vpQBI42UGBHAVKDrES3b7Zws/view?usp=sharing
gdown https://drive.google.com/file/d/1AkjqBoNOxUvS6sANIlHBMgdogu7yL3KE/view?usp=sharing
echo "######################### configurazione sulla macchina #########################"
unzip x backEnd.zip
unzip x frontEnd.zip
unzip x backEndServerFlask.zip
cd /home/ubuntu/backEnd
npm i
cd /home/ubuntu
cd /home/ubuntu/frontEnd
npm i
cd /home/ubuntu
pip3 --no-cache-dir install -r /home/ubuntu/backEndServerFlask/requirements.txt
python3 -m spacy download en_core_web_sm
echo "######################### Macchina pronta #########################"
